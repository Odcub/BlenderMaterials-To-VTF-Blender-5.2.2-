"""Scene settings and the Materials to VTF panel."""

import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, IntProperty, PointerProperty, StringProperty


class Material_List(bpy.types.PropertyGroup):
    material_checkbox: BoolProperty(name="Export", default=True)
    material_name: StringProperty(name="Material")
    material: PointerProperty(type=bpy.types.Material)


class UI_Settings(bpy.types.PropertyGroup):
    path: StringProperty(name="", subtype='DIR_PATH', maxlen=1024)


class VMT_Parameter(bpy.types.PropertyGroup):
    key: StringProperty(name="Key", description="VMT key, such as $selfillum")
    value: StringProperty(name="Value", description="VMT value")


class VTF_UL_materials(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.prop(item, "material_checkbox", text=item.material_name, icon='MATERIAL_DATA')


class VTF_UL_parameters(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, "key", text="", emboss=True)
        row.prop(item, "value", text="", emboss=True)


class VTF_OT_add_parameter(bpy.types.Operator):
    bl_idname = "vtf.add_parameter"
    bl_label = "Add VMT Parameter"

    def execute(self, context):
        context.scene.vmt_params.add()
        context.scene.vmt_params_index = len(context.scene.vmt_params) - 1
        return {'FINISHED'}


class VTF_OT_remove_parameter(bpy.types.Operator):
    bl_idname = "vtf.remove_parameter"
    bl_label = "Remove VMT Parameter"

    @classmethod
    def poll(cls, context):
        return bool(context.scene and context.scene.vmt_params)

    def execute(self, context):
        scene = context.scene
        scene.vmt_params.remove(min(max(scene.vmt_params_index, 0), len(scene.vmt_params) - 1))
        scene.vmt_params_index = min(scene.vmt_params_index, len(scene.vmt_params) - 1)
        return {'FINISHED'}


class VTFLibConverter(bpy.types.Panel):
    bl_label = "Materials to VTF"
    bl_idname = "SCENE_PT_vtflibconverter"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "scene"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        box = layout.box()
        box.label(text="Materials")
        box.template_list("VTF_UL_materials", "", scene, "mats_collection", scene, "mats_index", rows=4)
        box.operator("object.update_materials_list", icon='FILE_REFRESH')
        box.prop(scene, "skip_unused_materials")

        box = layout.box()
        box.label(text="Paths")
        box.prop(scene.VTFLibCmd, "path", text="VTFCmd Folder")
        box.prop(scene.material_path, "path", text="Output Folder")

        box = layout.box()
        box.label(text="VTF Settings")
        box.prop(scene, "format_op")
        box.prop(scene, "format_alpha_op")
        box.prop(scene, "vtf_version")
        box.prop(scene, "resize_bool")
        column = box.column(align=True)
        column.enabled = scene.resize_bool
        column.prop(scene, "resize_meth_op")
        column.prop(scene, "resize_filter_op")
        column.prop(scene, "resize_mode")
        if scene.resize_mode == 'CUSTOM':
            row = column.row(align=True)
            row.prop(scene, "resize_width")
            row.prop(scene, "resize_height")
        else:
            column.prop(scene, "clamp_op")

        box = layout.box()
        box.label(text="Material Images")
        box.prop(scene, "bake_width")
        box.prop(scene, "bake_height")
        box.prop(scene, "bake_layout")
        row = box.row()
        row.enabled = scene.bake_layout == 'MODEL_UV'
        row.prop(scene, "auto_uv_for_bake")
        box.prop(scene, "export_normals")
        row = box.row()
        row.enabled = scene.export_normals
        row.prop(scene, "normal_format_op")

        box = layout.box()
        box.prop(scene, "vmt_shader_bool")
        column = box.column()
        column.enabled = scene.vmt_shader_bool
        column.prop(scene, "vmt_shader_op")
        row = column.row(align=True)
        row.prop(scene, "vmt_param_additive")
        row.prop(scene, "vmt_param_translucent")
        row.prop(scene, "vmt_param_nocull")
        column.label(text="Custom VMT Parameters")
        row = column.row()
        row.template_list("VTF_UL_parameters", "", scene, "vmt_params", scene, "vmt_params_index", rows=2)
        buttons = row.column(align=True)
        buttons.operator("vtf.add_parameter", text="", icon='ADD')
        buttons.operator("vtf.remove_parameter", text="", icon='REMOVE')

        layout.operator("object.vtf_operator", icon='EXPORT')


classes = (
    Material_List, UI_Settings, VMT_Parameter, VTF_UL_materials, VTF_UL_parameters,
    VTF_OT_add_parameter, VTF_OT_remove_parameter, VTFLibConverter,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    scene = bpy.types.Scene
    scene.mats_collection = CollectionProperty(type=Material_List)
    scene.mats_index = IntProperty(default=0)
    scene.VTFLibCmd = PointerProperty(type=UI_Settings)
    scene.material_path = PointerProperty(type=UI_Settings)
    scene.format_op = EnumProperty(
        name="Opaque Format", default='dxt1',
        items=[('dxt1', "DXT1", "Small opaque texture"),
               ('dxt5', "DXT5", "Compressed color"),
               ('bgr888', "BGR888", "Uncompressed 24-bit color"),
               ('rgb888', "RGB888", "Uncompressed 24-bit color"),
               ('rgb565', "RGB565", "Uncompressed 16-bit color")],
    )
    scene.format_alpha_op = EnumProperty(
        name="Alpha Format", default='dxt5',
        items=[('dxt1_onebitalpha', "DXT1 One-Bit Alpha", "Binary transparency"),
               ('dxt3', "DXT3", "Explicit alpha"),
               ('dxt5', "DXT5", "Interpolated alpha"),
               ('bgra8888', "BGRA8888", "Uncompressed color and alpha"),
               ('rgba8888', "RGBA8888", "Uncompressed color and alpha")],
    )
    scene.normal_format_op = EnumProperty(
        name="Normal Format", default='dxt5',
        items=[('dxt5', "DXT5", "Compressed normal map"),
               ('bgr888', "BGR888", "Uncompressed normal map"),
               ('bgra8888', "BGRA8888", "Uncompressed normal map with alpha")],
    )
    scene.vtf_version = EnumProperty(
        name="VTF Version", default='7.5',
        items=[(version, version, "") for version in ('7.2', '7.3', '7.4', '7.5')],
    )
    scene.resize_bool = BoolProperty(name="Resize", default=False)
    scene.resize_mode = EnumProperty(
        name="Size", default='CLAMP',
        items=[('CLAMP', "Maximum Size", "Clamp both dimensions to a maximum"),
               ('CUSTOM', "Exact Size", "Resize to a chosen width and height")],
    )
    scene.resize_width = IntProperty(name="Width", default=512, min=1, max=4096)
    scene.resize_height = IntProperty(name="Height", default=512, min=1, max=4096)
    scene.clamp_op = EnumProperty(
        name="Maximum", default='512x512',
        items=[(f"{size}x{size}", f"{size}×{size}", "")
               for size in (2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096)],
    )
    scene.resize_meth_op = EnumProperty(
        name="Method", default='NEAREST',
        items=[(value, value.title(), "") for value in ('NEAREST', 'BIGGEST', 'SMALLEST')],
    )
    scene.resize_filter_op = EnumProperty(
        name="Filter", default='TRIANGLE',
        items=[(value, value.title(), "")
               for value in ('POINT', 'BOX', 'TRIANGLE', 'CUBIC', 'CATROM', 'MITCHELL')],
    )
    scene.bake_width = IntProperty(name="Bake Width", default=512, min=4, max=4096)
    scene.bake_height = IntProperty(name="Bake Height", default=512, min=4, max=4096)
    scene.bake_layout = EnumProperty(
        name="Bake Layout", default='FULL_IMAGE',
        items=[
            ('FULL_IMAGE', "Full Texture", "Bake across the whole image"),
            ('MODEL_UV', "Model UV Islands", "Bake only the model's UV islands"),
        ],
    )
    scene.auto_uv_for_bake = BoolProperty(
        name="Create Missing Bake UVs", default=True,
        description="Unwrap a temporary mesh copy when baking a material on a mesh without UVs",
    )
    scene.skip_unused_materials = BoolProperty(
        name="Skip Unused Material Slots", default=True,
        description="Ignore materials in unused slots and report their names after conversion",
    )
    scene.export_normals = BoolProperty(name="Export Normal Maps", default=True)
    scene.vmt_shader_bool = BoolProperty(name="Generate VMT", default=False)
    scene.vmt_shader_op = EnumProperty(
        name="Source Shader", default='VertexLitGeneric',
        items=[(value, value, "")
               for value in ('VertexLitGeneric', 'LightmappedGeneric', 'UnlitGeneric')],
    )
    scene.vmt_param_additive = BoolProperty(name="Additive", default=False)
    scene.vmt_param_translucent = BoolProperty(name="Translucent", default=False)
    scene.vmt_param_nocull = BoolProperty(name="No Cull", default=False)
    scene.vmt_params = CollectionProperty(type=VMT_Parameter)
    scene.vmt_params_index = IntProperty(default=0)


def unregister():
    scene = bpy.types.Scene
    for name in (
        "vmt_params_index", "vmt_params", "vmt_param_nocull", "vmt_param_translucent",
        "vmt_param_additive", "vmt_shader_op", "vmt_shader_bool", "export_normals",
        "skip_unused_materials", "auto_uv_for_bake", "bake_layout", "bake_height", "bake_width",
        "resize_filter_op", "resize_meth_op", "clamp_op",
        "resize_height", "resize_width", "resize_mode", "resize_bool", "vtf_version",
        "normal_format_op", "format_alpha_op", "format_op", "material_path", "VTFLibCmd",
        "mats_index", "mats_collection",
    ):
        delattr(scene, name)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
