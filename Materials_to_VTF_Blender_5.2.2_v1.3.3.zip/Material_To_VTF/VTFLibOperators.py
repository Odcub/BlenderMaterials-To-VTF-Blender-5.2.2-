"""Material discovery and conversion through the external VTFCmd tool."""

import os
import re
import shutil
import subprocess
import tempfile

import bpy

from . import MaterialExport


def _vtfcmd_path(raw_path):
    path = os.path.realpath(bpy.path.abspath(raw_path.strip()))
    return os.path.join(path, "VTFCmd.exe") if os.path.isdir(path) else path


def _needs_resize(dimensions):
    return bool(dimensions and any(size < 1 or size & (size - 1) for size in dimensions))


def _resize_args(scene, dimensions=None):
    if not scene.resize_bool and not _needs_resize(dimensions):
        return []
    args = ["-resize", "-rmethod", scene.resize_meth_op,
            "-rfilter", scene.resize_filter_op]
    if not scene.resize_bool:
        return args
    if scene.resize_mode == 'CUSTOM':
        args.extend(("-rwidth", str(scene.resize_width),
                     "-rheight", str(scene.resize_height)))
    else:
        clamp = scene.clamp_op.split('x', 1)[0]
        args.extend(("-rclampwidth", clamp, "-rclampheight", clamp))
    return args


def _command(scene, exe, source_path, output_dir, normal=False, dimensions=None):
    format_name = scene.normal_format_op if normal else scene.format_op
    alpha_format = scene.normal_format_op if normal else scene.format_alpha_op
    args = [exe, "-file", source_path,
            "-format", format_name, "-alphaformat", alpha_format,
            "-version", scene.vtf_version]
    args.extend(_resize_args(scene, dimensions))
    if normal:
        args.extend(("-flag", "NORMAL"))
    args.extend(("-output", output_dir))
    return args


def _run_vtfcmd(scene, exe, source_path, output_dir, name, normal=False,
                dimensions=None):
    args = _command(scene, exe, source_path, output_dir, normal, dimensions)
    result = subprocess.run(
        args, capture_output=True, text=True, errors="replace", check=False,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    output = "\n".join((result.stdout, result.stderr)).strip()
    if output:
        print("VTFCmd:\n" + output)
    completed = re.search(r"(\d+)\s*/\s*(\d+)\s+files completed", output, re.I)
    if result.returncode != 0 or completed is None or completed.group(1, 2) != ('1', '1'):
        raise ValueError("VTFCmd failed for " + name + ": " + (output[-400:] or "No diagnostic output"))
    result_path = os.path.join(output_dir, name + '.vtf')
    if not os.path.isfile(result_path):
        raise ValueError("VTFCmd did not create " + result_path)
    with open(result_path, 'rb') as handle:
        if handle.read(4) != b'VTF\x00':
            raise ValueError("VTFCmd output is not a valid VTF: " + result_path)
    return not scene.resize_bool and _needs_resize(dimensions)


def _stage_image(image, image_user, staging, name, scene=None, normal=False):
    source = MaterialExport.image_path(image, image_user)
    if normal and os.path.splitext(source)[1].lower() in {'.exr', '.hdr'}:
        staged = os.path.join(staging, name + '.png')
        MaterialExport.normal_png(source, staged, scene)
        return staged
    staged = os.path.join(staging, name + os.path.splitext(source)[1])
    shutil.copy2(source, staged)
    return staged


class update_materials_list(bpy.types.Operator):
    bl_idname = "object.update_materials_list"
    bl_label = "Refresh Materials List"
    bl_description = "List materials used by objects in the current scene"

    def execute(self, context):
        collection = context.scene.mats_collection
        selected = {item.material.name: item.material_checkbox
                    for item in collection if item.material is not None}
        collection.clear()
        seen = set()
        for obj in context.scene.objects:
            for index, slot in enumerate(obj.material_slots):
                material = slot.material
                if material is None or material.name in seen:
                    continue
                if (context.scene.skip_unused_materials
                        and not MaterialExport.material_is_used(context.scene, material)):
                    continue
                seen.add(material.name)
                item = collection.add()
                item.material = material
                item.material_name = material.name
                item.material_checkbox = selected.get(material.name, True)
        if not collection:
            self.report({'WARNING'}, "No materials are assigned to scene objects")
        return {'FINISHED'}


class vtf_operator(bpy.types.Operator):
    bl_idname = "object.vtf_operator"
    bl_label = "Convert"
    bl_description = "Export selected materials as VTF textures and optional VMT files"

    @classmethod
    def poll(cls, context):
        scene = context.scene
        return bool(scene and scene.VTFLibCmd.path.strip()
                    and scene.material_path.path.strip()
                    and any(item.material_checkbox for item in scene.mats_collection))

    def execute(self, context):
        scene = context.scene
        exe = _vtfcmd_path(scene.VTFLibCmd.path)
        output_dir = os.path.realpath(bpy.path.abspath(scene.material_path.path.strip()))
        if not os.path.isfile(exe):
            self.report({'ERROR'}, "VTFCmd.exe was not found: " + exe)
            return {'CANCELLED'}
        if not os.path.isdir(output_dir):
            self.report({'ERROR'}, "Material output folder was not found: " + output_dir)
            return {'CANCELLED'}

        selected = [item.material for item in scene.mats_collection
                    if item.material_checkbox and item.material is not None]
        if not selected:
            self.report({'ERROR'}, "Select at least one material")
            return {'CANCELLED'}

        plan = []
        skipped = []
        targets = set()
        try:
            for material in selected:
                name = MaterialExport.safe_name(material.name)
                if name.casefold() in targets:
                    raise ValueError("material names collide as Windows filenames: " + name)
                targets.add(name.casefold())
                try:
                    if (scene.skip_unused_materials
                            and not MaterialExport.material_is_used(scene, material)):
                        skipped.append(material.name)
                        continue
                    base_mode, base_data = MaterialExport.base_image_or_color(material)
                    if base_mode == 'BAKE' and scene.bake_layout == 'MODEL_UV':
                        MaterialExport._bake_source(
                            context, material, scene.auto_uv_for_bake)
                    normal = MaterialExport.normal_image(material) if scene.export_normals else None
                    if base_mode == 'IMAGE':
                        MaterialExport.image_path(*base_data)
                    if normal is not None:
                        MaterialExport.image_path(*normal)
                    if scene.vmt_shader_bool:
                        MaterialExport.vmt_text(scene, output_dir, name, normal is not None)
                except ValueError as exc:
                    raise ValueError(f"{material.name}: {exc}") from exc
                plan.append((material, name, base_mode, base_data, normal))

            if not plan:
                if skipped:
                    raise ValueError("No materials to convert; unused bake material(s): "
                                     + ", ".join(skipped))
                raise ValueError("No materials to convert")

            all_names = [name for _, name, _, _, _ in plan]
            all_names.extend(name + '_normal' for _, name, _, _, normal in plan if normal)
            if len({name.casefold() for name in all_names}) != len(all_names):
                raise ValueError("a normal-map filename collides with another material name")
        except ValueError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

        try:
            auto_resized = []
            with tempfile.TemporaryDirectory(prefix="blender_vtfcmd_") as staging:
                for material, name, mode, data, normal in plan:
                    if mode == 'IMAGE':
                        base_path = _stage_image(*data, staging, name)
                        base_size = tuple(data[0].size)
                    else:
                        base_path = os.path.join(staging, name + '.png')
                        base_size = (scene.bake_width, scene.bake_height)
                        if mode == 'SOLID':
                            MaterialExport.solid_image(
                                base_path, data, scene.bake_width, scene.bake_height)
                        else:
                            MaterialExport.bake_image(
                                context, material, base_path, scene.bake_width, scene.bake_height)
                    if _run_vtfcmd(scene, exe, base_path, output_dir, name,
                                   dimensions=base_size):
                        auto_resized.append(name)

                    if normal is not None:
                        normal_name = name + '_normal'
                        normal_path = _stage_image(*normal, staging, normal_name,
                                                   scene=scene, normal=True)
                        if _run_vtfcmd(scene, exe, normal_path, output_dir,
                                       normal_name, normal=True,
                                       dimensions=tuple(normal[0].size)):
                            auto_resized.append(normal_name)

                    if scene.vmt_shader_bool:
                        path = os.path.join(output_dir, name + '.vmt')
                        with open(path, 'w', encoding='utf-8', newline='\n') as file:
                            file.write(MaterialExport.vmt_text(
                                scene, output_dir, name, normal is not None))
        except (OSError, shutil.Error, ValueError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

        message = f"Converted {len(plan)} material(s) to {output_dir}"
        if auto_resized:
            message += f"; resized {len(auto_resized)} texture(s) to power-of-two dimensions"
        if skipped:
            message += f"; skipped {len(skipped)} unused material(s)"
        self.report({'INFO'}, message)
        if skipped:
            self.report({'WARNING'}, "Unused material slots skipped: " + ", ".join(skipped))
        return {'FINISHED'}


classes = (update_materials_list, vtf_operator)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
