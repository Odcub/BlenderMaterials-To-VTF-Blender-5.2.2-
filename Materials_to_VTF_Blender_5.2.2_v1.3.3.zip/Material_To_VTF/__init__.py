bl_info = {
    "name": "Materials to VTF",
    "description": "Convert image textures used by materials with VTFCmd",
    "author": "wenchien",
    "version": (1, 3, 3),
    "blender": (5, 2, 2),
    "location": "Properties > Scene > VTFLib Converter",
    "category": "Material",
}

from . import GUI, VTFLibOperators


def register():
    GUI.register()
    VTFLibOperators.register()


def unregister():
    VTFLibOperators.unregister()
    GUI.unregister()


if __name__ == "__main__":
    register()
