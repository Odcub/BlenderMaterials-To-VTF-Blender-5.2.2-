"""Read Blender shader graphs and prepare image files for VTFCmd."""

import os
import re

import bmesh
import bpy


def safe_name(name):
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).rstrip(" .") or "Material"


def image_path(image, image_user):
    if image.source != 'FILE' or image.packed_file:
        raise ValueError("requires an unpacked, file-backed image")
    if image.is_dirty:
        raise ValueError("has unsaved image changes; save the image first")
    path = os.path.realpath(bpy.path.abspath(image.filepath_from_user(image_user=image_user)))
    if not os.path.isfile(path):
        raise ValueError("image file does not exist: " + path)
    return path


def normal_png(source, path, scene):
    """Give old VTFCmd an 8-bit image when a normal map is stored as EXR/HDR."""
    temporary = bpy.data.images.load(source, check_existing=False)
    image_settings = scene.render.image_settings
    previous = (image_settings.file_format, image_settings.color_mode,
                image_settings.color_depth, scene.view_settings.view_transform)
    try:
        temporary.colorspace_settings.name = 'Non-Color'
        scene.view_settings.view_transform = 'Raw'
        image_settings.file_format = 'PNG'
        image_settings.color_mode = 'RGBA'
        image_settings.color_depth = '8'
        try:
            temporary.save_render(path, scene=scene)
        except RuntimeError as exc:
            raise ValueError("could not prepare normal map as PNG: " + str(exc)) from exc
    finally:
        (image_settings.file_format, image_settings.color_mode,
         image_settings.color_depth, scene.view_settings.view_transform) = previous
        bpy.data.images.remove(temporary)


def _linked_node(socket):
    return socket.links[0].from_node if socket is not None and socket.is_linked else None


def _shader_leaves(node, seen=None):
    seen = set() if seen is None else seen
    if node is None or node.as_pointer() in seen:
        raise ValueError("has an invalid or cyclic surface shader")
    seen.add(node.as_pointer())
    if node.bl_idname == 'ShaderNodeMixShader':
        leaves = []
        for socket in (node.inputs[1], node.inputs[2]):
            leaves.extend(_shader_leaves(_linked_node(socket), seen.copy()))
        return leaves
    if node.bl_idname in {'ShaderNodeBsdfPrincipled', 'ShaderNodeBsdfDiffuse'}:
        return [node]
    raise ValueError("uses an unsupported surface shader: " + node.bl_idname)


def shader_info(material):
    if material is None or material.node_tree is None:
        raise ValueError("requires shader nodes")
    outputs = [node for node in material.node_tree.nodes
               if node.bl_idname == 'ShaderNodeOutputMaterial']
    output = next((node for node in outputs if node.is_active_output), None)
    if output is None:
        raise ValueError("has no active Material Output node")
    shader = _linked_node(output.inputs.get('Surface'))
    leaves = _shader_leaves(shader)
    return shader, leaves


def _color_input(shader):
    key = 'Base Color' if shader.bl_idname == 'ShaderNodeBsdfPrincipled' else 'Color'
    return shader.inputs.get(key)


def _direct_image(socket):
    node = _linked_node(socket)
    if node is None or node.bl_idname != 'ShaderNodeTexImage':
        return None
    if node.image is None:
        raise ValueError("has an Image Texture node with no image")
    return node.image, node.image_user


def base_image_or_color(material):
    """Return (mode, image/user or color). Mixed and procedural shaders bake."""
    root, leaves = shader_info(material)
    if root.bl_idname == 'ShaderNodeMixShader':
        return 'BAKE', None
    color = _color_input(leaves[0])
    direct = _direct_image(color)
    if direct is not None:
        return 'IMAGE', direct
    if color is not None and not color.is_linked:
        return 'SOLID', tuple(color.default_value)
    return 'BAKE', None


def normal_image(material):
    _, leaves = shader_info(material)
    found = {}
    for shader in leaves:
        normal = shader.inputs.get('Normal')
        node = _linked_node(normal)
        if node is None:
            continue
        if node.bl_idname != 'ShaderNodeNormalMap':
            raise ValueError("has a Normal input that is not driven by a Normal Map node")
        direct = _direct_image(node.inputs.get('Color'))
        if direct is None:
            raise ValueError("has a Normal Map node without a directly linked Image Texture")
        found[direct[0].as_pointer()] = direct
    if len(found) > 1:
        raise ValueError("uses multiple normal maps; only one can be exported per material")
    return next(iter(found.values()), None)


def solid_image(path, color, width, height):
    image = bpy.data.images.new("VTF solid color", width=width, height=height, alpha=False)
    try:
        image.generated_color = tuple(color[:3]) + (1.0,)
        image.file_format = 'PNG'
        image.save(filepath=path, save_copy=True)
    finally:
        bpy.data.images.remove(image)


def mesh_face_users(context, material):
    """Find mesh faces that actually use a material, ignoring spare slots."""
    users = []
    for obj in context.scene.objects:
        if obj.type != 'MESH':
            continue
        for index, slot in enumerate(obj.material_slots):
            if slot.material == material and any(poly.material_index == index for poly in obj.data.polygons):
                users.append((obj, index))
    return users


def material_is_used(scene, material):
    """Whether any scene geometry actually uses this material."""
    for obj in scene.objects:
        for index, slot in enumerate(obj.material_slots):
            if slot.material != material:
                continue
            if obj.type != 'MESH' or any(poly.material_index == index for poly in obj.data.polygons):
                return True
    return False


def _bake_source(context, material, auto_uv=False):
    users = mesh_face_users(context, material)
    if not users:
        raise ValueError("has no mesh faces using this material to bake")
    for obj, index in users:
        if obj.data.uv_layers.active is not None:
            return obj, index
    if auto_uv:
        return users[0]
    raise ValueError("needs an active UV map on a mesh using this material")


def _full_image_mesh():
    """Make a temporary plane whose UVs cover the entire output image."""
    mesh = bpy.data.meshes.new("VTF full image bake")
    mesh.from_pydata(
        [(-1, -1, 0), (1, -1, 0), (1, 1, 0), (-1, 1, 0)],
        [], [(0, 1, 2, 3)],
    )
    mesh.update()
    uv = mesh.uv_layers.new(name="VTF Full Image")
    for loop in mesh.loops:
        vertex = mesh.vertices[loop.vertex_index]
        uv.data[loop.index].uv = ((vertex.co.x + 1) / 2, (vertex.co.y + 1) / 2)
    return mesh


def bake_image(context, material, path, width, height):
    """Bake the diffuse color pass on temporary copies; leave the scene intact."""
    scene = context.scene
    full_image = scene.bake_layout == 'FULL_IMAGE'
    if full_image:
        source, material_index = None, None
    else:
        source, material_index = _bake_source(context, material, scene.auto_uv_for_bake)
    old_engine = scene.render.engine
    old_active = context.view_layer.objects.active
    old_mode = old_active.mode if old_active is not None else 'OBJECT'
    old_selected = list(context.selected_objects)
    old_bake_target = scene.render.bake.target
    mesh = _full_image_mesh() if full_image else source.data.copy()
    copied_material = material.copy()
    temp_obj = bpy.data.objects.new("VTF temporary bake", mesh)
    image = None

    try:
        scene.collection.objects.link(temp_obj)
        if not full_image:
            bm = bmesh.new()
            try:
                bm.from_mesh(mesh)
                unwanted = [face for face in bm.faces if face.material_index != material_index]
                if unwanted:
                    bmesh.ops.delete(bm, geom=unwanted, context='FACES')
                bm.to_mesh(mesh)
            finally:
                bm.free()
        if not mesh.polygons:
            raise ValueError("has no faces to bake")
        mesh.materials.clear()
        mesh.materials.append(copied_material)
        for poly in mesh.polygons:
            poly.material_index = 0
        if source is not None:
            temp_obj.matrix_world = source.matrix_world.copy()

        image = bpy.data.images.new("VTF temporary bake", width=width, height=height, alpha=False)
        target = copied_material.node_tree.nodes.new('ShaderNodeTexImage')
        target.image = image
        for node in copied_material.node_tree.nodes:
            node.select = False
        target.select = True
        copied_material.node_tree.nodes.active = target

        if old_active is not None and old_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        temp_obj.select_set(True)
        context.view_layer.objects.active = temp_obj
        if mesh.uv_layers.active is None:
            mesh.uv_layers.new(name="VTF Auto UV")
            bpy.ops.object.mode_set(mode='EDIT')
            try:
                bpy.ops.mesh.select_all(action='SELECT')
                if bpy.ops.uv.smart_project(island_margin=0.02) != {'FINISHED'}:
                    raise ValueError("could not create a UV map for baking")
            finally:
                bpy.ops.object.mode_set(mode='OBJECT')
        scene.render.engine = 'CYCLES'
        scene.render.bake.target = 'IMAGE_TEXTURES'
        result = bpy.ops.object.bake(type='DIFFUSE', pass_filter={'COLOR'})
        if result != {'FINISHED'}:
            raise ValueError("Blender could not bake the diffuse color")
        image.file_format = 'PNG'
        image.save(filepath=path, save_copy=True)
    except RuntimeError as exc:
        raise ValueError("Blender bake failed: " + str(exc)) from exc
    finally:
        scene.render.engine = old_engine
        scene.render.bake.target = old_bake_target
        bpy.data.objects.remove(temp_obj, do_unlink=True)
        bpy.data.meshes.remove(mesh)
        bpy.data.materials.remove(copied_material)
        if image is not None:
            bpy.data.images.remove(image)
        bpy.ops.object.select_all(action='DESELECT')
        for obj in old_selected:
            if obj.name in bpy.data.objects:
                obj.select_set(True)
        context.view_layer.objects.active = old_active
        if old_active is not None and old_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode=old_mode)


def vmt_parameters(scene):
    params = {}
    for enabled, key in ((scene.vmt_param_additive, '$additive'),
                         (scene.vmt_param_translucent, '$translucent'),
                         (scene.vmt_param_nocull, '$nocull')):
        if enabled:
            params[key] = '1'
    for item in scene.vmt_params:
        key = item.key.strip()
        key = key if key.startswith('$') else '$' + key
        value = item.value.strip()
        if not re.fullmatch(r'\$[A-Za-z_][A-Za-z0-9_]*', key):
            raise ValueError("invalid custom VMT key: " + item.key)
        if key.lower() in ('$basetexture', '$bumpmap') or key.lower() in params:
            raise ValueError("duplicate or reserved custom VMT key: " + key)
        if any(char in value for char in ('"', '\r', '\n')):
            raise ValueError("VMT values cannot contain quotes or newlines: " + key)
        params[key] = value
    return params


def vmt_text(scene, output_dir, name, has_normal):
    if has_normal and scene.vmt_shader_op == 'UnlitGeneric':
        raise ValueError("normal maps require VertexLitGeneric or LightmappedGeneric")
    parts = os.path.normpath(output_dir).split(os.sep)
    materials = [i for i, part in enumerate(parts) if part.casefold() == 'materials']
    prefix = '/'.join(parts[materials[-1] + 1:]) if materials else ''
    base = '/'.join(part for part in (prefix, name) if part)
    params = {'$basetexture': base}
    if has_normal:
        params['$bumpmap'] = base + '_normal'
    params.update(vmt_parameters(scene))
    body = '\n'.join(f'    "{key}" "{value}"' for key, value in params.items())
    return f'{scene.vmt_shader_op}\n{{\n{body}\n}}\n'
